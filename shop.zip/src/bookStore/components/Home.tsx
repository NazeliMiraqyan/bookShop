import Items from "./Items"
import BorderImage from "./BorderImage"



const Home:React.FC=()=>{

    return(
        <>
            <BorderImage/>
            <Items/>
          
        </>
    )
}
export default Home